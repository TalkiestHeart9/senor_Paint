package main.java.com.example.demo;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.control.Slider;

import javax.imageio.ImageIO;
import java.awt.Label;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.layout.StackPane;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;




class Paint extends Application {

    class ResizableCanvas extends Canvas {

        public ResizableCanvas() {
            // Redraw canvas when size changes.
            widthProperty().addListener(evt -> draw());
            heightProperty().addListener(evt -> draw());
        }

        private void draw() {
            double width = getWidth();
            double height = getHeight();

            GraphicsContext gc = getGraphicsContext2D();
            gc.clearRect(0, 0, width, height);

            gc.setStroke(Color.RED);
            gc.strokeLine(0, 0, width, height);
            gc.strokeLine(0, height, width, 0);
        }

        @Override
        public boolean isResizable() {
            return true;
        }

        @Override
        public double prefWidth(double height) {
            return getWidth();
        }

        @Override
        public double prefHeight(double width) {
            return getHeight();
        }
    }

    @Override
    public void start(Stage stage) throws Exception {
        ResizableCanvas canvas = new ResizableCanvas();

        StackPane stackPane = new StackPane();
        //make a scrolling pane
        ScrollPane sp = new ScrollPane();

        sp.setContent(canvas);

        sp.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

        stackPane.getChildren().add(sp);

        // Bind canvas size to stack pane size.
        canvas.widthProperty().bind(
                stackPane.widthProperty());
        canvas.heightProperty().bind(
                stackPane.heightProperty());

        stage.setScene(new Scene(stackPane));
        stage.setTitle("Tip 1: Resizable Canvas");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

public class senor_paint extends Application {

    // The filepath of the currently opened file
    private static String filePath;


    private Timer autosaveTimer = new Timer(); // Autosave timer

    private final static double TOTAL_WIDTH = 1000 ;

    final ScrollBar scrollBar = new ScrollBar();

    final static int CANVAS_WIDTH = 400;
    final static int CANVAS_HEIGHT = 400;

    private KeyCombination ctrlO = new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN);
    private KeyCombination ctrlS = new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN);

    public static double x1;
    public static double y1;

    public static double x2;
    public static double y2;

    static boolean saved = false;

    static boolean drawfree = false;
    static int drawline = 0;
    static int drawsquare = 0;
    static int drawrec = 0;
    static int drawelipse = 0;
    static int drawsircle = 0;
    static int coolshape = 0;
    static int erasetool = 0;
    static int drawpoly = 0;

    static File imageloc = null;

    static int saveauto = 0;

    static int currentLineWidth=2;

    //Width selector slider for line width and text size, etc

    Slider lineWidthSlider = new Slider(1, 50, 5);

    ColorPicker colorPicker;

    @Override

    public void start(Stage stage) throws IOException {

        String shape; // What shape

        //create a white box
        BorderPane root = new BorderPane();
        Scene s = new Scene(root, 1200, 800, Color.WHITE);
        //fill that space with a canvas
        final Canvas canvas = new Canvas(2000, 1500);
        GraphicsContext gc = canvas.getGraphicsContext2D();   //add a graphics context so we can interact with our canvas
        //create new instance fileChooser
        final FileChooser fileChooser = new FileChooser();

        ScrollBar scrollBar = new ScrollBar();
        scrollBar.setMin(0);
        scrollBar.setMax(TOTAL_WIDTH - canvas.getWidth());

        scrollBar.setVisibleAmount(scrollBar.getMax() * canvas.getWidth() / TOTAL_WIDTH);
/**********************************************************************************************************************/
       //make a background
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, 1500, 1500);
        initDraw(gc);
        //make top menu bar
        HBox hBox = new HBox();
        hBox.getChildren().addAll(colorPicker,lineWidthSlider);
        ScrollBar bar = new ScrollBar();

        VBox vBox = new VBox();
        vBox.layoutYProperty().bind(bar.valueProperty());
        vBox.getChildren().addAll(hBox, canvas, scrollBar);
        root.getChildren().add(vBox);

        //name the window
        stage.setTitle("Señor Paint");
        stage.setScene(s);
        stage.show();

/**********************************************************************************************************************/
        //make menu items
        MenuItem open = new MenuItem("Open");                //create menu item open
        MenuItem save = new MenuItem("Save");                //create menu item save
        MenuItem saveAs = new MenuItem("Save As");           //create menu item save as
        MenuItem autosave = new MenuItem("Auto Save");
        MenuItem exit = new MenuItem("Exit");                //create menu item exit
        MenuItem about = new MenuItem("About");              //create menu item about
        MenuItem help1 = new MenuItem("Help");
        MenuItem freeline = new MenuItem("Free Hand");
        MenuItem line = new MenuItem("Straight Line");
        MenuItem square = new MenuItem("Square");
        MenuItem rectangle = new MenuItem("Rectangle");
        MenuItem elipse = new MenuItem("Elipse");
        MenuItem circle = new MenuItem("Circle");
        MenuItem zoomi = new MenuItem("Zoom In");
        MenuItem zoomo = new MenuItem("Zoom Out");
        MenuItem cshape = new MenuItem("Cool Shape");
        MenuItem none = new MenuItem("None");
        MenuItem polygon = new MenuItem("Polygon");
        MenuItem erase = new MenuItem("Erase");
        //fill menus with items
        Menu drawing = new Menu("_Drawing");
        drawing.getItems().addAll(freeline, line, square, rectangle, elipse, circle, cshape, polygon, none, erase);

        // Create Menus with items
        Menu file = new Menu("_File");      // Underscore in text allows user to press ALT + character after underscore to open menu
        file.getItems().addAll(open, save, saveAs, autosave, exit, zoomi, zoomo);     //fill menu bar item file with open, save, save as, and exit

        Menu help = new Menu("_Help");       // Underscore in text allows user to press ALT + character after underscore to open menu
        help.getItems().addAll(about,help1);       //fill menu bar item file with open, save, save as, and exit

        MenuBar menuBar = new MenuBar();


        /**************************************************************************************************************/

        Alert alert = new Alert(Alert.AlertType.WARNING,
                "You are about to exit without saving."
                        + "Would you like to save? ");
                ButtonType okButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
                ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
                ButtonType cancelButton = new ButtonType("cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.setTitle("Save before leaving.");

        //create a button for open
        Button openButton = new Button();
        openButton.setGraphic(new ImageView(new Image("file:src/Images/OpenButton.png", 15, 15, false, false)));
        openButton.setMinSize(25, 25);
        openButton.setTooltip(new Tooltip("(Ctrl+O)\nOpen an image to work with."));
        //handles opening files
        openButton.setOnAction((ActionEvent Tam) -> {
            //allow the user to select a file
            File image = fileChooser.showOpenDialog(stage);
            imageloc = image;
            //convert our image file to a string
            Image image2 = new Image(image.toURI().toString());

            WritableImage wim = new WritableImage(image2.getPixelReader(), (int) image2.getWidth(), (int) image2.getHeight());
            //display the image on our canvas
            gc.fillRect(0, 0, image2.getWidth(), image2.getHeight());
            initDraw(gc);
            canvas.getGraphicsContext2D().drawImage(wim, 0, 0);
            saved = false;
        });
        //add file to the menubar
        menuBar.getMenus().addAll(file, help, drawing);
        //include canvas
        root.getChildren().add(canvas);
        root.setBottom(menuBar);              //include the menu bar I worked oh so hard to make

/**********************************************************************************************************************/
        open.setOnAction((ActionEvent t) -> {
            openButton.fire(); // Call the open button's action
        });
        //close the program when exit is clicked
        exit.setOnAction((ActionEvent t) -> {
                // Checking if file has been saved since last changes
            if(!saved){
                alert.getButtonTypes().setAll(okButton, noButton, cancelButton);

                    //ButtonType result = alert.showAndWait().orElse(ButtonType.NO);

                    Optional<ButtonType> result = alert.showAndWait();

                    if (result.get() == ButtonType.NO) {
                        System.out.println("pants");
                        Platform.exit();
                        System.exit(0);

                    }

                    else if (result.get() == ButtonType.YES) {
                        save.fire();
                        System.out.println("pants2");
                    }

                    else {
                        System.out.println("pants3");
                        Platform.exit();
                        System.exit(0);

                    }
            }
            else{
                //End program and close window
                System.out.println("pants4");
                Platform.exit();
                System.exit(0);

            }
        });

        //save as button
        saveAs.setOnAction((ActionEvent t) -> {

            WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
            //Set extension filter
            FileChooser fileChooser2 = new FileChooser();
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png");
            fileChooser2.getExtensionFilters().add(extFilter);

            File file2 = fileChooser2.showSaveDialog(stage);

            imageloc = file2;

            try {
                if (file2 != null) {
                    ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file2);

                }
            } catch (IOException ex) {
                System.out.println(ex.toString());
            }
            saved = true;
        });

        autosave.setOnAction((ActionEvent t) -> {

            if(saveauto == 0) {
                saveauto = 1;

                WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
                //Set extension filter
                FileChooser fileChooser2 = new FileChooser();
                FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png");
                fileChooser2.getExtensionFilters().add(extFilter);

                File file2 = fileChooser2.showSaveDialog(stage);

                try {
                    if (file2 != null) {
                        ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file2);
                    }
                } catch (IOException ex) {
                    System.out.println(ex.toString());
                }
                saved = true;

            }
            else{
                saveauto = 0;
            }
            class SayHello extends TimerTask {
                public void run() {
                    save.fire();
                }
            }

            if (saveauto == 1){

                System.out.println("Auto save is on");
// And From your main() method or any other method
                Timer timer = new Timer();
                timer.schedule(new SayHello(), 0, 5000);

            }
            else{

            }
        });


        save.setOnAction((ActionEvent t) -> {
            WritableImage image = canvas.snapshot(new SnapshotParameters(), null);

            try {
                if (imageloc != null) {
                    ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", imageloc);
                }
            } catch (IOException ex) {
                System.out.println(ex.toString());
            }
            saved = true;
        });
        //help button
        help1.setOnAction((ActionEvent t) -> {
            Label label5 = new Label("You can save and open files in the file menu, as well as call on file with alt f." +
                    "You can choose what shape to draw in the drawing tab.  Don't forget to select none to deselect any of the options." +
                    "ctrl s saves and ctrl o opens files.");
            System.out.println("You can save and open files in the file menu, as well as call on file with alt f."  +
                    "You can choose what shape to draw in the drawing tab.  Don't forget to select none to deselect any of the options." +
                    "ctrl s saves and ctrl o opens files.");
        });
        //zoom in button
        zoomi.setOnAction((ActionEvent t) -> {
            canvas.setScaleX(2);
            canvas.setScaleY(2);
        });
        //zoom out button
        zoomo.setOnAction((ActionEvent t) -> {
            canvas.setScaleX(1);
            canvas.setScaleY(1);
        });
        //freeline button
        freeline.setOnAction((ActionEvent t) -> {
            drawfree = !drawfree;
            System.out.println("freeline works");
        });

        none.setOnAction((ActionEvent t) -> {

            drawfree = false;
            drawline = 0;
            drawelipse = 0;
            drawsircle = 0;
            drawsquare = 0;
            drawrec = 0;
            coolshape = 0;
            erasetool = 0;
            drawpoly = 0;

        });

        erase.setOnAction((ActionEvent t) -> {
            if (erasetool == 0){
                erasetool = 1;
            }
            else if (erasetool == 1){
                erasetool = 0;
            }
        });
        //straight line button
        line.setOnAction((ActionEvent t) -> {
            if (drawline == 0){
                drawline = 1;
            }
            else if (drawline == 1){
                drawline = 0;
            }
        });

        cshape.setOnAction((ActionEvent t) -> {
            if (coolshape == 0){
                coolshape = 1;
            }
            else if (coolshape == 1){
                coolshape = 0;
            }
        });

        square.setOnAction((ActionEvent t) -> {
            if (drawsquare == 0){
                drawsquare = 1;
            }
            else if (drawsquare == 1){
                drawsquare = 0;
            }
        });

        rectangle.setOnAction((ActionEvent t) -> {
            if (drawrec == 0){
                drawrec = 1;
            }
            else if (drawrec == 1){
                drawrec = 0;
            }
        });

        elipse.setOnAction((ActionEvent t) -> {
            if (drawelipse == 0){
                drawelipse = 1;
            }
            else if (drawelipse == 1){
                drawelipse = 0;
            }
        });

        circle.setOnAction((ActionEvent t) -> {
            if (drawsircle == 0){
                drawsircle = 1;
            }
            else if (drawsircle == 1){
                drawsircle = 0;
            }
        });
        polygon.setOnAction((ActionEvent t) -> {
            if (drawpoly == 0){
                drawpoly = 1;
            }
            else if (drawpoly == 1){
                drawpoly = 0;
            }
        });

        //when the mouse is pressed, draw based on selected tool
            canvas.addEventHandler(MouseEvent.MOUSE_PRESSED,
                    new EventHandler<MouseEvent>() {

                @Override
                public void handle (MouseEvent event){
                    if (drawfree){
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        gc.setStroke(colorPicker.getValue());
                        gc.setLineWidth(lineWidthSlider.getValue());
                        gc.stroke();
                        System.out.println("Freeline drawing is on.");
                    }
                    if (erasetool == 1){
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        gc.setStroke(Color.WHITE);
                        gc.setLineWidth(lineWidthSlider.getValue());
                        gc.stroke();
                        System.out.println("Erase drawing is on.");
                    }
                    if(drawelipse == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                        System.out.println("Elipse drawing is on.");
                    }

                    if(drawsircle == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                        System.out.println("Circle drawing is on.");
                    }

                    if(drawsquare == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                        System.out.println("Square drawing is on.");
                    }
                    if(drawrec == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                        System.out.println("Rectangle drawing is on.");
                    }
                    if(drawline == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                        System.out.println("Straight line drawing is on.");
                    }
                    if(drawpoly == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                        System.out.println("Polygon drawing is on.");
                    }
                    if(coolshape == 1) {
                        gc.beginPath();
                        gc.moveTo(event.getX(), event.getY());
                        x1 = event.getX();
                        y1 = event.getY();
                    }
                    saved = false;
                }
            });

            //Handle mouse being dragged

            canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED,
                    new EventHandler<MouseEvent>() {

                        @Override
                        public void handle(MouseEvent event) {
                            if (drawfree) {
                                gc.lineTo(event.getX(), event.getY());
                                gc.setStroke(colorPicker.getValue());
                                gc.setLineWidth(lineWidthSlider.getValue());
                                gc.stroke();
                            }
                            if (erasetool == 1) {
                                gc.lineTo(event.getX(), event.getY());
                                gc.setStroke(Color.WHITE);
                                gc.setLineWidth(lineWidthSlider.getValue());
                                gc.stroke();
                            }
                        }
                    });

            //Handle mouse being released
            canvas.addEventHandler(MouseEvent.MOUSE_RELEASED,
                    new EventHandler<MouseEvent>() {

                        @Override
                        public void handle(MouseEvent event) {
                            if(drawelipse == 1) {
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                double width = Math.abs(x1 - x2);
                                double height = Math.abs(y1 - y2);

                                double xs = Math.min(x1, x2);
                                double ys = Math.min(y1, y2);

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.fillOval(xs, ys, width, height);
                            }

                            if(drawsircle == 1) {
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                double width = Math.abs(x1 - x2);
                                double height = Math.abs(y1 - y2);

                                double xs = Math.min(x1, x2);
                                double ys = Math.min(y1, y2);

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.fillOval(xs, ys, width, width);
                            }

                            if(drawsquare == 1) {
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                double width = Math.abs(x1 - x2);
                                double height = Math.abs(y1 - y2);

                                double xs = Math.min(x1, x2);
                                double ys = Math.min(y1, y2);

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.fillRect(xs, ys, width, width);
                            }
                            if(drawpoly == 1) {
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.fillPolygon(null, null, 5);
                            }
                            if(drawrec == 1) {
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                double width = Math.abs(x1 - x2);
                                double height = Math.abs(y1 - y2);

                                double xs = Math.min(x1, x2);
                                double ys = Math.min(y1, y2);

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.fillRect(xs, ys, width, height);
                            }
                            if(drawline == 1) {
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                double width = Math.abs(x1 - x2);
                                double height = Math.abs(y1 - y2);

                                double xs = Math.min(x1, x2);
                                double ys = Math.min(y1, y2);

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.strokeLine(x1, y1, x2, y2);
                            }
                            if(coolshape == 1){
                                gc.moveTo(event.getX(), event.getY());
                                x2 = event.getX();
                                y2 = event.getY();

                                double width = Math.abs(x1 - x2);
                                double height = Math.abs(y1 - y2);

                                double xs = Math.min(x1, x2);
                                double ys = Math.min(y1, y2);

                                gc.setFill(colorPicker.getValue());
                                gc.setStroke(colorPicker.getValue());

                                gc.strokeRect(xs, ys, width, height);
                                gc.strokeRect(xs, ys, width, width);
                                gc.strokeOval(xs, ys, width, width);
                                gc.strokeOval(xs, ys, width, height);
                            }
                        }
                    });
        stage.addEventHandler(KeyEvent.KEY_PRESSED, (KeyEvent t) -> {
            if (ctrlO.match(t)) {
                open.fire(); // Open if user presses Ctrl+O
            }

            else if(ctrlS.match(t)){
                save.fire(); // Save file if user presses Ctrl+S
            }
        });
    }
    //runs the program
    public static void main(String[] args) {
        launch();
    }

/**********************************************************************************************************************/
    //color picker creator
    private void initDraw(GraphicsContext gc){

        colorPicker = new ColorPicker();

        Slider lineWidthSlider = new Slider(1, 50, 5); //range 1 to 50 with default 5
        //show ticks
        lineWidthSlider.setShowTickMarks(true);
        lineWidthSlider.setShowTickLabels(true);
        lineWidthSlider.setMajorTickUnit(49);
        lineWidthSlider.setMinorTickCount(48);

        double canvasWidth = gc.getCanvas().getWidth();
        double canvasHeight = gc.getCanvas().getHeight();
        //define line variables
        gc.setFill(Color.WHITE);
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(lineWidthSlider.getValue());

        gc.fill();
        gc.strokeRect(
                0,              //x of the upper left corner
                0,              //y of the upper left corner
                canvasWidth,    //width of the rectangle
                canvasHeight);  //height of the rectangle

        gc.setFill(colorPicker.getValue());
        gc.setStroke(colorPicker.getValue());
        gc.setLineWidth(lineWidthSlider.getValue());
    }
}


package main.java.com.example.demo;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;


import static org.junit.Assert.*;

import static org.junit.Assert.assertFalse;


public class Test{

    public static int test = 1;

    public static double x1;
    public static double y1;

    public static double x2;
    public static double y2;

    double width = Math.abs(x1 - x2);
    double height = Math.abs(y1 - y2);

    public void TimerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @org.junit.Test
    public void testtest() {

        assertTrue(test == 1);

    }

    @org.junit.Test
    public void testMouseCalc() {

        x1 = 2;
        x2 = 5;

        y1 = 2;
        y2 = 5;


        assertFalse(width == 3);
        assertFalse(height == 3);
    }

    @org.junit.Test
    public void circleoff() {

        assertFalse(height == 3);
    }
}